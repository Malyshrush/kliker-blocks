# Kliker Blocks graph library

The graph prompts and on-canvas annotations are in Russian. Use this English guide for setup. Open an example through Graph library or open its Scenario.klb directly. Keep the sample files beside the graph.

| Graph | Setup and result |
| --- | --- |
| 11 · Redact a screenshot | Open demo.html. Confirm the prompt, then aim and press F8 at the top-left and bottom-right of the screenshot, then at the two corners of each mask. Release F8 between picks. The two BufferReplace blocks set the mask color. The output variable names the PNG. Review the result before sharing. |
| 12 · Count icons | Open demo.html. Confirm and mark two corners of one red icon, then two corners of the search area, with F8. Expect three matches in the log. The image scan tolerance controls how closely colors must match. |
| 15 · Spoken interval timer | Enter work and rest seconds (1–600) and rounds (1–50). The three input blocks set the defaults. The voice settings are in the Speak text blocks. The sample uses Russian phrases and falls back to beeps if the voice is unavailable. |
| 16 · Flashcards | Open cards.txt or a UTF-8 file with one question and answer per line separated by a vertical bar. Review items are saved to the file named by review_path. |
| 17 · Step-by-step guide | Open steps.txt or a UTF-8 file with one step per line. Set note position and size in the first Note block. Choose Yes to advance or No to stop. |
| 20 · Watch a window | Set window_title to a distinctive part of the window title. Set app_path to the executable, shortcut or document to open after the window disappears and you choose Yes. For the same window use demo.html; for a different page use another-demo.html. Monitoring still targets the original title. Optional arguments are in Run file. |
| 21 · Check a local service | Set health_url, health_key and expected_state in the first three variable blocks. Demo-Health.ps1 is an optional loopback test server. Run it yourself in PowerShell with -Mode Healthy or -Mode Degraded. The graph writes service-health.log. |

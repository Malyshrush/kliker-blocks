param(
    [ValidateSet('Healthy','Degraded','Unavailable','InvalidJson','Slow')]
    [string]$Mode = 'Healthy',
    [ValidateRange(1024,65535)][int]$Port = 8765
)
$ErrorActionPreference = 'Stop'
$listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback, $Port)
$listener.Start()
try {
    Write-Host "Demo health server: http://127.0.0.1:$Port/health.json ($Mode). Ctrl+C stops it."
    while ($true) {
        $client = $listener.AcceptTcpClient()
        try {
            $stream = $client.GetStream()
            $stream.ReadTimeout = 2000
            $stream.WriteTimeout = 2000
            $reader = [IO.StreamReader]::new($stream, [Text.Encoding]::ASCII, $false, 1024, $true)
            try {
                $request = $reader.ReadLine()
                for ($i = 0; $i -lt 64; $i++) { if (-not $reader.ReadLine()) { break } }
            } finally { $reader.Dispose() }
            $status = '200 OK'
            $body = switch ($Mode) {
                Healthy { '{"status":"ok"}' }
                Degraded { '{"status":"degraded"}' }
                Unavailable { $status = '503 Service Unavailable'; '{"status":"unavailable"}' }
                InvalidJson { 'Not JSON' }
                Slow { Start-Sleep -Seconds 10; '{"status":"ok"}' }
            }
            if ($request -notlike 'GET /health.json HTTP/*') { $status = '404 Not Found'; $body = '{}' }
            $newline = [string][char]13 + [char]10
            $response = @("HTTP/1.1 $status", 'Content-Type: application/json', "Content-Length: $($body.Length)", 'Connection: close', '', $body) -join $newline
            $bytes = [Text.Encoding]::ASCII.GetBytes($response)
            $stream.Write($bytes, 0, $bytes.Length)
        } catch [IO.IOException] {
            # A timed-out or closed client does not stop the demo server.
        } finally { $client.Dispose() }
    }
} finally { $listener.Stop() }
